import 'package:flutter/material.dart';
import 'dart:math';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: LuckyBall(),
    );
  }
}

class LuckyBall extends StatefulWidget {
  const LuckyBall({super.key});

  @override
  _LuckyBallState createState() => _LuckyBallState();
}

class _LuckyBallState extends State<LuckyBall> {
  List<String> luckImages = [
    "assets/ball1.png",
    "assets/ball2.png",
    "assets/ball3.png",
    "assets/ball4.png",
    "assets/ball5.png",
  ];


  Random random = Random();
  String currentImage = "assets/ball0.png";

  void changeImage() {
    int randomIndex = random.nextInt(luckImages.length);
    setState(() {
      currentImage = luckImages[randomIndex];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bola de la Suerte'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                changeImage();
              },
              child: Container(
                width: 500,
                height: 500,
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
                child: Center(
                  child: Image.asset(
                    currentImage,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
